document.addEventListener("DOMContentLoaded", function () {
    const signInButton = document.querySelector(".signin-section button");
    const signUpLink = document.querySelector(".signin-section a");

    signInButton.addEventListener("click", function () {
        window.location.href = "login.html";
    });

    signUpLink.addEventListener("click", function (e) {
        e.preventDefault();
        window.location.href = "signup.html";
    });
});


const images = [
    "pics/back1.jpg",
    "pics/back2.jpg",
    "pics/back3.jpg",
    "pics/back4.jpg"
  ];

  let current = 0;
  const slider = document.getElementById("slider");

  setInterval(() => {
    current = (current + 1) % images.length;
    slider.src = images[current];
  }, 3000); // 2 seconds
